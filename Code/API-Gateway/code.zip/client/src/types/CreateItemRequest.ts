export interface CreateItemRequest {
  itemId: string
  name: string
  price: string
}
